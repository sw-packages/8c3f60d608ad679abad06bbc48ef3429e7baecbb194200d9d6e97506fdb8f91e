// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause
#include <QKeySequence>

namespace src_gui_kernel_qshortcutmap {

void wrapper() {
QKeySequence key;

//! [0]
key = QKeySequence();
//! [0]

} // wrapper
} // src_gui_kernel_qshortcutmap
